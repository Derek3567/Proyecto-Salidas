# Control Salidas V4.0.4

Versión estable del sistema institucional.

## Configuración de cuenta

La página incluye un botón de configuración en Inicio. Las preferencias se guardan en la tabla `configuraciones_usuario` asociada al usuario autenticado.

Opciones:
- Fondo: `fondo_claro1`, `fondo_claro2`, `fondo_claro3`, `fondo_oscuro1`, `fondo_oscuro2`, `fondo_oscuro3` o `sin_fondo`.
- Modo predeterminado: claro u oscuro.
- Imágenes decorativas: activadas o desactivadas.
- Color institucional: blanco + azul o blanco + rojo.
- Borrado definitivo por semestres: permanece dentro de Configuración y conserva la protección de V3.11.

### Valores predeterminados
- Fondo: `fondo_claro1`.
- Modo: `claro`.
- Imágenes decorativas: activadas.
- Color institucional: `azul`.

Los fondos MP4 se encuentran en `assets/`. No eliminar `private_uploads/ines`, porque contiene las INEs persistentes de los alumnos.

## Base de datos
La tabla `configuraciones_usuario` debe existir. El archivo `database/migracion_v3_12_configuraciones.sql` contiene su definición con los valores predeterminados actuales.

No es necesario volver a crear las tablas existentes de alumnos, tutores o usuarios.

## Pase de salida
El código de generación del Pase de Salida no fue modificado en V3.12.3.

## V3.13 — cierre de V3
- Mantiene el logo CBTIS con sus colores/archivo originales en el tema rojo.
- Añade filtros de Reportes y Consultas por semestre, grupo y especialidad.
- La exportación CSV conserva el formato de intercambio compatible con Excel.
- Añade exportación Excel `.xlsx` con bordes, anchos de columna, filtros automáticos y encabezado congelado.
- La exportación respeta los filtros y orden aplicados en pantalla.
- No modifica la generación del Pase de Salida.

## V4.0.0 — Cuentas del personal
- Añade el botón «+ Añadir cuenta» junto al acceso de Inicio de sesión.
- Las nuevas cuentas usan nombre, correo y contraseña con los mismos requisitos del acceso.
- Máximo absoluto de 12 cuentas en `usuarios_sistema`, validado en servidor.
- Cada cuenta nueva recibe automáticamente una fila en `configuraciones_usuario` con los valores predeterminados actuales.
- Las cuentas comparten los registros de alumnos, tutores y reportes; no se filtran por cuenta porque el sistema es institucional a nivel preparatoria.
- Las personalizaciones de interfaz sí permanecen asociadas a cada cuenta.
- No requiere cambios adicionales de estructura de base de datos.

## Instalación en la computadora de la preparatoria

1. Coloca el contenido de este proyecto en `C:\xampp\htdocs\control_salidas\`.
2. En phpMyAdmin ejecuta `database/control_salidas.sql`.
3. El proyecto ya incluye `config.php` configurado para `control_salidas`.
4. Inicia Apache y MySQL desde XAMPP.
5. Abre `http://localhost/control_salidas/`.
6. Usa `setup.php` una sola vez para crear la primera cuenta y después elimínalo.

El sistema comparte alumnos y tutores entre todas las cuentas del personal. Las cuentas solamente separan contraseñas y personalizaciones.


## V4.0.1 — Turno y búsqueda avanzada de INEs
- Se añadió `alumnos.turno` con `Matutino` / `Vespertino`.
- La búsqueda de INEs permite nombre o matrícula y filtros de especialidad, semestre y turno.
- Turno aparece en altas, edición, listados, reportes y exportaciones.


V4.0.2: incluye config.php para XAMPP local (base de datos control_salidas) y corrige la tabla de Reportes y Consultas para mostrar las 7 columnas sin espacio vertical desperdiciado.


## V4.0.4 — UX de Reportes y selección de INE
- Corrige el acomodo de los filtros y el ordenamiento de Reportes y Consultas para evitar amontonamiento.
- Permite doble clic sobre una imagen de INE registrada para cargar tutor, alumno y parentesco en el formulario del pase.
- Al seleccionar una INE también se autocompleta el grupo del pase como `semestre grupo` (por ejemplo, `5 A`).
- La verificación del tutor sigue siendo obligatoria después del autocompletado.
