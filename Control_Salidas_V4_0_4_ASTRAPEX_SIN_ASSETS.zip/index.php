<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Control de Pases de Salida</title>
  <script>window.APP_CONFIG = { apiBase: "api", databaseMode: true };</script>
  <script src="db-adapter.js?v=4.0.4" defer></script>
  <meta name="description" content="Sistema local para verificar tutores y generar pases de salida.">
  <link rel="stylesheet" href="style.css?v=4.0.4">
</head>
<body>
  <video autoplay muted loop playsinline id="si" aria-hidden="true"><source id="backgroundVideoSource" src="assets/fondo_claro1.mp4" type="video/mp4"></video>
  <div class="video-overlay" aria-hidden="true"></div>
  <div id="floatingDecor" class="floating-decor-layer" aria-hidden="true">
    <div class="floating-decor decor-dgeti" data-size="large">
      <img src="assets/decor-dgeti.png" alt="">
    </div>
    <div class="floating-decor decor-cbtis" data-size="medium">
      <img src="assets/decor-cbtis.png" alt="">
    </div>
    <div class="floating-decor decor-snake" data-size="small">
      <img src="assets/decor-serpiente.png" alt="">
    </div>
  </div>
  <div id="pageTransition" class="page-transition" aria-hidden="true"><span class="transition-ring"></span><span class="transition-ring ring-2"></span><span class="transition-core"></span></div>
  <div id="themePaint" class="theme-paint" aria-hidden="true"></div>
  <div id="toast" class="toast"></div>

  <div id="settingsModal" class="reset-modal settings-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="settingsModalTitle">
    <div class="reset-modal-card settings-card" role="document">
      <div class="settings-head">
        <div class="reset-modal-icon settings-icon" aria-hidden="true">⚙</div>
        <div class="reset-modal-content"><p class="eyebrow">CONFIGURACIÓN DE CUENTA</p><h3 id="settingsModalTitle">Personaliza tu sistema</h3><p>Estas opciones se guardan en tu cuenta y se aplican cada vez que inicias sesión.</p></div>
      </div>
      <div class="settings-body">
        <section class="settings-section"><div class="settings-section-head"><div><strong>Fondo de la página</strong><span>Elige uno de los seis fondos preparados o deja la interfaz sin video.</span></div></div>
          <div class="background-options" id="backgroundOptions">
            <button class="background-option" type="button" data-background="fondo_oscuro1"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_oscuro1.mp4" type="video/mp4"></video></span><strong>Oscuro 1</strong><small>Oscuro</small></button>
            <button class="background-option" type="button" data-background="fondo_oscuro2"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_oscuro2.mp4" type="video/mp4"></video></span><strong>Oscuro 2</strong><small>Oscuro</small></button>
            <button class="background-option" type="button" data-background="fondo_oscuro3"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_oscuro3.mp4" type="video/mp4"></video></span><strong>Oscuro 3</strong><small>Oscuro</small></button>
            <button class="background-option" type="button" data-background="fondo_claro1"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_claro1.mp4" type="video/mp4"></video></span><strong>Claro 1</strong><small>Claro</small></button>
            <button class="background-option" type="button" data-background="fondo_claro2"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_claro2.mp4" type="video/mp4"></video></span><strong>Claro 2</strong><small>Claro</small></button>
            <button class="background-option" type="button" data-background="fondo_claro3"><span class="background-preview"><video muted loop playsinline preload="metadata"><source src="assets/fondo_claro3.mp4" type="video/mp4"></video></span><strong>Claro 3</strong><small>Claro</small></button>
            <button class="background-option no-background-option" type="button" data-background="sin_fondo"><span class="background-preview no-background-preview"><span>∅</span></span><strong>Sin fondo</strong><small>Interfaz limpia</small></button>
          </div>
        </section>
        <div class="settings-side">
          <section class="settings-section"><div class="settings-section-head"><div><strong>Modo predeterminado</strong><span>Se aplicará automáticamente al entrar con esta cuenta.</span></div></div>
            <div class="settings-choice-row" role="group" aria-label="Modo predeterminado"><button class="settings-choice" type="button" data-mode="claro">☀ <span>Claro</span></button><button class="settings-choice" type="button" data-mode="oscuro">☾ <span>Oscuro</span></button></div>
          </section>
          <section class="settings-section"><div class="settings-section-head"><div><strong>Imágenes decorativas</strong><span>Activa o desactiva las imágenes flotantes del fondo.</span></div></div>
            <div class="settings-choice-row" role="group" aria-label="Imágenes decorativas"><button class="settings-choice" type="button" data-decor="1">✓ <span>Activadas</span></button><button class="settings-choice" type="button" data-decor="0">× <span>Desactivadas</span></button></div>
          </section>
          <section class="settings-section"><div class="settings-section-head"><div><strong>Color institucional</strong><span>Cambia la identidad visual de la interfaz sin modificar el Pase de Salida.</span></div></div>
            <div class="settings-choice-row" role="group" aria-label="Color institucional"><button class="settings-choice color-choice-blue" type="button" data-color="azul"><span class="color-dot"></span><span>Blanco + azul</span></button><button class="settings-choice color-choice-red" type="button" data-color="rojo"><span class="color-dot"></span><span>Blanco + rojo</span></button></div>
          </section>
        </div>
        <section class="settings-danger-section"><div><strong>Zona administrativa</strong><span>El borrado de registros permanece protegido por contraseña, selección de semestres, espera y pulsación sostenida.</span></div><button id="settingsPurgeBtn" class="purge-open-btn" type="button">⚠ Borrar registros</button></section>
      </div>
      <div class="reset-modal-actions settings-actions"><button id="closeSettingsBtn" class="secondary-btn" type="button">Cerrar</button><button id="saveSettingsBtn" class="primary-btn" type="button">Guardar configuración</button></div>
    </div>
  </div>

  <div id="deleteModal" class="reset-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="deleteModalTitle">
    <div class="reset-modal-card delete-modal-card" role="document">
      <div class="reset-modal-icon delete-modal-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7M7 7l.7 12.1a1.5 1.5 0 0 0 1.5 1.4h5.6a1.5 1.5 0 0 0 1.5-1.4L17 7M10 11v6M14 11v6"/></svg>
      </div>
      <div class="reset-modal-content">
        <p class="eyebrow">DAR DE BAJA</p>
        <h3 id="deleteModalTitle">¿Confirmar baja?</h3>
        <p id="deleteModalText">Esta acción desactivará el registro seleccionado.</p>
      </div>
      <div class="reset-modal-actions">
        <button id="cancelDeleteBtn" class="secondary-btn" type="button">Cancelar</button>
        <button id="confirmDeleteBtn" class="modal-danger-btn" type="button">Sí, dar de baja</button>
      </div>
    </div>
  </div>

  <div id="tutorModal" class="reset-modal tutor-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="tutorModalTitle">
    <div class="reset-modal-card tutor-modal-card" role="document">
      <div class="reset-modal-icon tutor-modal-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M16 20v-1.7a3.3 3.3 0 0 0-3.3-3.3H6.3A3.3 3.3 0 0 0 3 18.3V20M9.5 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM16 11a3 3 0 1 0 0-6M17 15h4M19 13v4"/></svg>
      </div>
      <div class="reset-modal-content">
        <p class="eyebrow" id="tutorModalEyebrow">TUTOR AUTORIZADO</p>
        <h3 id="tutorModalTitle">Añadir tutor</h3>
        <p id="tutorModalSubtitle">Captura los datos del tutor para este alumno.</p>
      </div>
      <form id="tutorModalForm" class="tutor-modal-form">
        <input id="tutorModalId" type="hidden" value="">
        <input id="tutorModalSlot" type="hidden" value="-1">
        <input id="tutorModalStudentId" type="hidden" value="">
        <label>Nombres<input id="tutorModalNames" type="text" maxlength="75" autocomplete="off" required></label>
        <label>Apellidos<input id="tutorModalApellidos" type="text" maxlength="75" autocomplete="off" required></label>
        <label>Parentesco<select id="tutorModalRelationship" required><option value="">Seleccionar...</option><option>Madre</option><option>Padre</option><option>Tutor legal</option><option>Abuela</option><option>Abuelo</option><option>Otro autorizado</option></select></label>
        <label>Número telefónico<input id="tutorModalPhone" type="tel" maxlength="30" autocomplete="tel" required></label>
        <div class="tutor-ine-field">
          <div class="tutor-ine-label"><strong>INE del tutor</strong><span>1 por tutor · máximo 3 MB</span></div>
          <div id="tutorInePreview" class="tutor-ine-preview"><span>Sin INE seleccionada</span></div>
          <input id="tutorModalIne" type="file" accept="image/jpeg,image/png,image/webp" hidden>
          <button id="chooseTutorIneBtn" class="secondary-btn" type="button">+ Añadir INE</button>
          <small class="field-help">Cada tutor debe tener una sola imagen de INE.</small>
        </div>
        <div class="tutor-modal-actions">
          <button id="removeTutorFromFormBtn" class="delete-user tutor-remove-btn hidden" type="button">Quitar tutor</button>
          <span></span>
          <button id="cancelTutorModalBtn" class="secondary-btn" type="button">Cancelar</button>
          <button id="saveTutorModalBtn" class="primary-btn" type="submit">Guardar tutor</button>
        </div>
      </form>
    </div>
  </div>

  <div id="ineSearchModal" class="reset-modal ine-search-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="ineSearchModalTitle">
    <div class="reset-modal-card ine-search-card" role="document">
      <div class="reset-modal-icon ine-search-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM16 16l4 4M7.5 10.5h6M10.5 7.5v6"/></svg>
      </div>
      <div class="reset-modal-content">
        <p class="eyebrow">CONSULTA DE INEs</p>
        <h3 id="ineSearchModalTitle">Buscar INE de un alumno</h3>
        <p id="ineSearchModalSubtitle">Busca al alumno y selecciona su registro para consultar las INEs asociadas.</p>
      </div>
      <div class="ine-browser">
        <div id="ineStudentListView">
          <div class="ine-search-toolbar">
            <label class="ine-search-input"><span>Buscar alumno o matrícula</span><input id="ineStudentSearch" type="search" placeholder="Nombre o matrícula..." autocomplete="off"></label>
            <div class="ine-search-filters" aria-label="Filtros de alumnos">
              <label><span>Semestre</span><select id="ineSemesterFilter"><option value="">Todos</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option></select></label>
              <label><span>Especialidad</span><select id="ineSpecialtyFilter"><option value="">Todas</option><option>Programacion</option><option>Inteligencia Artificial</option><option>Contabilidad</option><option>Servicios de Hospedaje</option><option>Alimentos y Bebidas</option><option>Mecanica Industrial</option><option>Logistica</option></select></label>
              <label><span>Turno</span><select id="ineShiftFilter"><option value="">Todos</option><option>Matutino</option><option>Vespertino</option></select></label>
            </div>
            <div class="ine-sort" role="group" aria-label="Ordenar alumnos">
              <span>Ordenar</span>
              <button class="ine-sort-btn active" data-ine-sort="name-asc" type="button">Nombre A-Z</button>
              <button class="ine-sort-btn" data-ine-sort="name-desc" type="button">Nombre Z-A</button>
              <button class="ine-sort-btn" data-ine-sort="semester-desc" type="button">Semestre ↓</button>
              <button class="ine-sort-btn" data-ine-sort="semester-asc" type="button">Semestre ↑</button>
            </div>
          </div>
          <div id="ineStudentList" class="ine-student-list"></div>
        </div>
        <div id="ineStudentDetailView" class="ine-detail-view hidden">
          <div class="ine-detail-head">
            <button id="ineBackToStudentsBtn" class="secondary-btn" type="button">← Volver a alumnos</button>
            <div><strong id="ineSelectedStudentName">Alumno</strong><span id="ineSelectedStudentMeta"></span></div>
          </div>
          <div id="ineSlotsGrid" class="ine-slots-grid"></div>
        </div>
      </div>
      <div class="reset-modal-actions">
        <button id="closeIneSearchBtn" class="secondary-btn" type="button">Cerrar</button>
      </div>
    </div>
  </div>

  <div id="purgePasswordModal" class="reset-modal purge-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="purgePasswordTitle">
    <div class="reset-modal-card purge-password-card" role="document">
      <div class="reset-modal-icon purge-icon" aria-hidden="true">🔐</div>
      <div class="reset-modal-content">
        <p class="eyebrow">LIMPIEZA DE DATOS</p>
        <h3 id="purgePasswordTitle">Verificar contraseña</h3>
        <p>Este proceso elimina definitivamente alumnos, tutores e INEs de los semestres que selecciones. Primero verifica la contraseña de tu cuenta.</p>
        <label class="purge-password-label">Contraseña de la cuenta<input id="purgePasswordInput" name="purge_security_password" type="password" minlength="10" autocomplete="new-password" autocapitalize="none" spellcheck="false" readonly placeholder="Escribe tu contraseña"></label>
        <small id="purgePasswordHelp" class="field-help">La contraseña se verifica en el servidor y no se guarda.</small>
      </div>
      <div class="reset-modal-actions">
        <button id="cancelPurgePasswordBtn" class="secondary-btn" type="button">Cancelar</button>
        <button id="verifyPurgePasswordBtn" class="modal-danger-btn" type="button">Continuar</button>
      </div>
    </div>
  </div>

  <div id="purgeConfirmModal" class="reset-modal purge-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="purgeConfirmTitle">
    <div class="reset-modal-card purge-confirm-card" role="document">
      <div class="reset-modal-icon purge-icon">⚠</div>
      <div class="reset-modal-content">
        <p class="eyebrow">BORRADO DEFINITIVO</p>
        <h3 id="purgeConfirmTitle">Eliminar generaciones completas</h3>
        <p>Selecciona los semestres que se retirarán definitivamente. Esta acción no utiliza la baja lógica y no se puede deshacer desde el sistema.</p>
      </div>
      <div class="purge-semester-box">
        <div class="purge-semester-head"><strong>Semestres</strong><span id="purgeSelectedCount">0 seleccionados</span></div>
        <div class="purge-semester-grid">
          <label><input class="purge-semester-check" type="checkbox" value="1"><span>1° semestre</span></label>
          <label><input class="purge-semester-check" type="checkbox" value="2"><span>2° semestre</span></label>
          <label><input class="purge-semester-check" type="checkbox" value="3"><span>3° semestre</span></label>
          <label><input class="purge-semester-check" type="checkbox" value="4"><span>4° semestre</span></label>
          <label><input class="purge-semester-check" type="checkbox" value="5"><span>5° semestre</span></label>
          <label><input class="purge-semester-check" type="checkbox" value="6"><span>6° semestre</span></label>
        </div>
      </div>
      <div class="purge-countdown" aria-live="polite">
        <span id="purgeCountdownText">El botón se habilitará en 6 segundos.</span>
        <div class="purge-countdown-bar"><span id="purgeCountdownBar"></span></div>
      </div>
      <div class="purge-hold-wrap">
        <button id="holdPurgeBtn" class="purge-hold-btn" type="button" disabled>
          <span class="purge-hold-progress"></span><span class="purge-hold-label">Mantén pulsado 3 segundos para borrar</span>
        </button>
        <small id="purgeHoldStatus">Primero espera los 6 segundos y selecciona al menos un semestre.</small>
      </div>
      <div class="reset-modal-actions">
        <button id="cancelPurgeConfirmBtn" class="secondary-btn" type="button">Cancelar</button>
      </div>
    </div>
  </div>

  <div id="resetModal" class="reset-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="resetModalTitle">
    <div class="reset-modal-card" role="document">
      <div class="reset-modal-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7M7 7l.7 12.1a1.5 1.5 0 0 0 1.5 1.4h5.6a1.5 1.5 0 0 0 1.5-1.4L17 7M10 11v6M14 11v6"/></svg>
      </div>
      <div class="reset-modal-content">
        <p class="eyebrow">REINICIAR REGISTRO</p>
        <h3 id="resetModalTitle">¿Estás seguro?</h3>
        <p>Se borrarán los datos capturados del pase actual. Los registros autorizados y los folios recientes permanecerán guardados.</p>
      </div>
      <div class="reset-modal-actions">
        <button id="cancelResetBtn" class="secondary-btn" type="button">Cancelar</button>
        <button id="confirmResetBtn" class="modal-danger-btn" type="button">Sí, reiniciar</button>
      </div>
    </div>
  </div>

  <main id="login" class="screen login-screen">
    <div class="login-glow"></div>
    <section class="login-card">
      <div class="brand-mark cbtis-brand"><img src="assets/cbtis.png" alt="Logo CBTIS"></div>
      <p class="eyebrow">ACCESO AL SISTEMA</p>
      <h1>Iniciar sesión</h1>
      <p class="login-copy">Ingresa tus datos para acceder al sistema.</p>
      <form id="loginForm" class="login-form">
        <label>Nombre<input id="loginName" type="text" required autocomplete="name" maxlength="120"></label>
        <label>Correo electrónico<input id="loginEmail" type="email" required autocomplete="email"></label>
        <label>Contraseña<input id="loginPassword" type="password" required minlength="10" autocomplete="current-password" aria-describedby="passwordHelp"></label>
        <small id="passwordHelp" class="field-help">Mínimo 10 caracteres, sin espacios, con número, letra y mayúscula.</small>
        <div class="login-actions">
          <button class="primary-btn login-btn" type="submit">Entrar <span class="arrow">→</span></button>
          <button id="openAccountModalBtn" class="secondary-btn add-account-btn" type="button" aria-haspopup="dialog" aria-controls="accountModal">+ Añadir cuenta</button>
        </div>
      </form>
    </section>
  </main>

  <div id="accountModal" class="reset-modal account-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="accountModalTitle">
    <div class="reset-modal-card account-modal-card" role="document">
      <div class="reset-modal-icon account-modal-icon" aria-hidden="true">+</div>
      <div class="reset-modal-content">
        <p class="eyebrow">NUEVA CUENTA</p>
        <h3 id="accountModalTitle">Añadir cuenta</h3>
        <p>Crea una cuenta nueva para otro miembro del personal. El límite del sistema es de 12 cuentas y todas comparten los registros de la preparatoria.</p>
      </div>
      <form id="accountForm" class="account-form">
        <label>Nombre<input id="accountName" type="text" required maxlength="120" autocomplete="name"></label>
        <label>Correo electrónico<input id="accountEmail" type="email" required autocomplete="email"></label>
        <label>Contraseña<input id="accountPassword" type="password" required minlength="10" autocomplete="new-password" aria-describedby="accountPasswordHelp"></label>
        <small id="accountPasswordHelp" class="field-help">Mínimo 10 caracteres, sin espacios, con número, letra y mayúscula.</small>
        <div class="account-modal-actions">
          <button id="closeAccountModalBtn" class="secondary-btn" type="button">Cancelar</button>
          <button class="primary-btn" type="submit">Crear cuenta</button>
        </div>
      </form>
    </div>
  </div>

  <main id="home" class="screen home-screen">
    <div class="home-glow"></div>
    <div class="home-card">
      <div class="home-brand-logo"><img src="assets/logo-astrapex.png" alt="Logo ASTRAPEX"></div>
      <p class="eyebrow">CONTROL ESCOLAR</p>
      <h1>ASTRAPEX</h1>
      <div class="home-copy home-descriptions"><p><strong>Ir a Registros:</strong> administra alumnos y tutores.</p><p><strong>Iniciar sistema:</strong> verifica tutores y genera pases de salida.</p></div>
      <div class="home-actions">
        <button id="recordsHomeBtn" class="secondary-btn home-records-btn" type="button"><span>▣</span><span>Ir a Registros</span><span class="arrow">→</span></button>
      <button id="startBtn" class="primary-btn start-btn" type="button"><span class="start-icon"><i></i></span><span>Iniciar sistema</span><span class="arrow">→</span></button>
      </div>
      <div class="home-account-actions"><button id="logoutBtn" class="home-logout-btn" type="button">Cerrar sesión</button><button id="openSettingsBtn" class="settings-home-btn" type="button" aria-haspopup="dialog" aria-controls="settingsModal" aria-label="Configuración de la cuenta" title="Configuración de la cuenta"><span class="settings-gear" aria-hidden="true">⚙</span></button></div>
    </div>
  </main>

  <main id="records" class="screen records-screen hidden">
    <section class="records-shell">
      <header class="records-topbar">
        <div><p class="eyebrow">CONTROL ESCOLAR</p><h2>Registros de alumnos</h2><p class="records-subtitle">Administra altas, bajas, consultas y modificaciones sin mezclar esta zona con el Sistema de Salida.</p></div>
        <div class="records-nav-actions"><button id="recordsThemeToggle" class="theme-toggle records-theme-toggle" type="button" aria-label="Activar modo oscuro" aria-pressed="false" title="Cambiar tema"><svg class="sun-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4.2"></circle><path d="M12 1.7v2.2M12 20.1v2.2M1.7 12h2.2M20.1 12h2.2M4.7 4.7l1.55 1.55M17.75 17.75l1.55 1.55M19.3 4.7l-1.55 1.55M6.25 17.75L4.7 19.3"></path></svg></button><button id="backFromRecordsBtn" class="ghost-btn" type="button">← Inicio</button><button id="recordsSystemBtn" class="ghost-btn" type="button">Ir al Sistema →</button></div>
      </header>

      <div class="records-tabs" role="tablist" aria-label="Administración, reportes y consultas">
        <button class="records-tab active" data-records-view="users" type="button">Alumnos</button>
        <button class="records-tab" data-records-view="authorized" type="button">Añadir tutores</button>
        <button class="records-tab records-tab-featured" data-records-view="reports" type="button"><span aria-hidden="true">▤</span> Reportes y Consultas</button>
      </div>

      <section id="usersRecordsView" class="records-view active-records-view">
        <div class="records-heading"><div><p class="eyebrow">ADMINISTRACIÓN</p><h3>Alumnos registrados</h3></div><span class="badge neutral" id="userCountBadge">0 alumnos</span></div>
        <div class="records-layout">
          <form id="userForm" class="user-form">
            <input id="editingUserIndex" type="hidden" value="-1">
            <div class="records-form-title"><strong id="userFormTitle">Registrar alumno</strong><span>Base de datos</span></div>
            <div class="form-grid">
              <label>Nombres<input id="uNombres" type="text" required autocomplete="off" maxlength="75"></label>
              <label>Apellidos<input id="uApellidos" type="text" required autocomplete="off" maxlength="75"></label>
              <label id="matriculaField">Matrícula<input id="uMatricula" type="text" required autocomplete="off"></label>
              <label>Semestre<select id="uSemestre" required><option value="">Seleccionar...</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option></select></label>
              <label>Turno<select id="uTurno" required><option value="">Seleccionar...</option><option>Matutino</option><option>Vespertino</option></select></label>
              <label>Grupo<input id="uGrupo" type="text" required maxlength="1" autocomplete="off"></label>
              <label class="wide">Especialidad<select id="uEspecialidad" required><option value="">Seleccionar...</option><option>Programacion</option><option>Inteligencia Artificial</option><option>Contabilidad</option><option>Servicios de Hospedaje</option><option>Alimentos y Bebidas</option><option>Mecanica Industrial</option><option>Logistica</option></select></label>
              <div class="wide tutor-manager">
                <div class="tutor-manager-head"><div><strong>Tutores autorizados</strong><small>Agrega de 1 a 4 tutores para este alumno.</small></div><span id="tutorCount">0/4</span></div>
                <div id="tutorSlots" class="tutor-slots" aria-label="Tutores autorizados del alumno"></div>
                <p class="field-help tutor-manager-help">Haz clic en un espacio para registrar un tutor. Los datos de cada tutor se guardan junto con el alumno al pulsar «Registrar alumno».</p>
              </div>
            </div>
            <div class="record-form-actions"><button id="cancelEditBtn" class="secondary-btn hidden" type="button">Cancelar edición</button><button class="primary-btn" type="submit" id="saveUserBtn">Registrar alumno</button></div>
          </form>

          <div class="user-list-card">
            <div class="list-toolbar"><div><strong>Consulta rápida</strong><p class="muted">Busca por nombre, matrícula, grupo o tutor.</p></div><input id="userSearch" type="search" placeholder="Buscar alumno..." autocomplete="off"></div>
            <div id="usersList" class="users-list"></div>
          </div>
        </div>
      </section>

      <section id="authorizedRecordsView" class="records-view">
        <div class="records-heading"><div><p class="eyebrow">ADMINISTRACIÓN</p><h3>Añadir tutores a un alumno</h3><p class="muted">Selecciona un alumno para agregar, modificar o dar de baja sus tutores autorizados. Cada alumno puede tener hasta 4.</p></div><input id="registrySearch" type="search" placeholder="Buscar alumno, matrícula o tutor..." autocomplete="off"></div>
        <div id="registryList" class="tutor-students-list"></div>
      </section>

      <section id="reportsRecordsView" class="records-view">
        <div class="records-heading reports-heading">
          <div><p class="eyebrow">CONSULTAS</p><h3>Reportes y Consultas</h3><p class="muted">Consulta todos los alumnos y los tutores asociados en una sola tabla, preparada para copiar o exportar a Excel.</p></div>
          <div class="reports-heading-actions"><span class="badge neutral" id="reportCountBadge">0 alumnos</span><button id="exportReportsCsvBtn" class="secondary-btn reports-export-btn" type="button">↓ CSV</button><button id="exportReportsXlsxBtn" class="primary-btn reports-export-btn" type="button">▣ Excel</button></div>
        </div>
        <div class="reports-toolbar">
          <label class="reports-search"><span>Buscar alumno</span><input id="reportsSearch" type="search" placeholder="Escribe el nombre del alumno..." autocomplete="off"></label>
          <div class="reports-filters" aria-label="Filtrar reporte">
            <label><span>Semestre</span><select id="reportsSemesterFilter"><option value="">Todos</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option></select></label>
            <label><span>Grupo</span><select id="reportsGroupFilter"><option value="">Todos</option></select></label>
            <label><span>Especialidad</span><select id="reportsSpecialtyFilter"><option value="">Todas</option></select></label>
            <label><span>Turno</span><select id="reportsShiftFilter"><option value="">Todos</option><option>Matutino</option><option>Vespertino</option></select></label>
          </div>
          <div class="reports-sort" role="group" aria-label="Ordenar reporte">
            <span>Ordenar por</span>
            <button class="report-sort-btn active" data-report-sort="name-asc" type="button">Nombre A-Z</button>
            <button class="report-sort-btn" data-report-sort="name-desc" type="button">Nombre Z-A</button>
            <button class="report-sort-btn" data-report-sort="tutors-desc" type="button">Más tutores</button>
            <button class="report-sort-btn" data-report-sort="tutors-asc" type="button">Menos tutores</button>
            <button class="report-sort-btn" data-report-sort="semester-desc" type="button">Semestre ↓</button>
          </div>
        </div>
        <div class="report-table-card">
          <div class="report-table-scroll">
            <table id="reportsTable" class="reports-table">
              <thead id="reportsTableHead"></thead>
              <tbody id="reportsTableBody"></tbody>
            </table>
          </div>
          <div id="reportsEmpty" class="reports-empty hidden"></div>
        </div>
        <p class="reports-note">La vista muestra los tutores de forma compacta. Puedes filtrar por semestre, grupo, especialidad y turno. CSV conserva los datos para intercambio; Excel genera un archivo con tabla, bordes, filtros y encabezado congelado.</p>
      </section>
    </section>
  </main>

  <main id="app" class="screen app-screen hidden">
    <header class="topbar">
      <div>
        <p class="eyebrow">CONTROL ESCOLAR</p>
        <h2>Generador de pase de salida</h2>
      </div>
      <div class="topbar-actions">
        <button id="recordsBtn" class="ghost-btn" type="button">Ir a Registros</button>
        <button id="themeToggle" class="theme-toggle" type="button" aria-label="Activar modo oscuro" aria-pressed="false" title="Cambiar tema">
          <svg class="sun-icon" viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="12" cy="12" r="4.2"></circle>
            <path d="M12 1.7v2.2M12 20.1v2.2M1.7 12h2.2M20.1 12h2.2M4.7 4.7l1.55 1.55M17.75 17.75l1.55 1.55M19.3 4.7l-1.55 1.55M6.25 17.75L4.7 19.3"></path>
          </svg>
        </button>
        <button id="resetBtn" class="reset-btn" type="button" aria-label="Reiniciar datos" title="Reiniciar datos">
          <svg class="reset-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M20 11a8 8 0 0 0-14.9-3.9L3 9.5"></path>
            <path d="M3 4.8v4.7h4.7"></path>
            <path d="M4 13a8 8 0 0 0 14.9 3.9L21 14.5"></path>
            <path d="M21 19.2v-4.7h-4.7"></path>
          </svg>
        </button>
        <button id="backHomeBtn" class="ghost-btn">Inicio</button>
      </div>
    </header>

    <nav class="steps" aria-label="Secciones">
      <button class="step active" data-step="1"><b>01</b><span>Verificar tutor</span></button>
      <button class="step" data-step="2"><b>02</b><span>Datos del pase</span></button>
      <button class="step" data-step="3"><b>03</b><span>Vista previa</span></button>
    </nav>

    <section id="step1" class="panel step-panel active-panel">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">SECCIÓN 01</p>
          <h3>Verificar que el tutor esté autorizado</h3>
        </div>
        <span id="authBadge" class="badge neutral">Sin verificar</span>
      </div>

      <div class="notice">
        <strong>Antes de generar el pase:</strong> compara los datos del tutor con el registro autorizado. Esta comprobación es local y no sustituye la validación oficial de la escuela.
      </div>

      <div class="form-grid">
        <label>Tutor que recoge al alumno
          <input id="tutorName" type="text" placeholder="Nombre completo" autocomplete="off">
        </label>
        <label>Alumno
          <input id="studentName" type="text" placeholder="Nombre completo del alumno" autocomplete="off">
        </label>
        <label>Parentesco
          <select id="relationship">
            <option value="">Seleccionar...</option>
            <option>Madre</option><option>Padre</option><option>Tutor legal</option>
            <option>Abuela</option><option>Abuelo</option><option>Otro autorizado</option>
          </select>
        </label>
        <div class="ine-search-action-wrap">
          <button id="openIneSearchBtn" class="secondary-btn ine-search-open-btn" type="button"><span aria-hidden="true">⌕</span> Buscar INEs</button>
          <small>Consulta las INEs registradas del alumno antes de verificar al tutor.</small>
        </div>
      </div>

      <div class="actions">
        <button id="verifyBtn" class="primary-btn">Verificar autorización</button>
      </div>

      <div id="authResult" class="result-card neutral-result">
        <span class="result-icon">?</span>
        <div><strong>Aún no se ha realizado una verificación.</strong><p>Introduce los datos y pulsa “Verificar autorización”.</p></div>
      </div>

      <div class="panel-footer">
        <button class="secondary-btn next-btn" data-next="2" disabled id="toFormBtn">Continuar a datos</button>
      </div>
    </section>

    <section id="step2" class="panel step-panel">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">SECCIÓN 02</p>
          <h3>Capturar datos del pase</h3>
        </div>
        <span class="badge ok">Tutor autorizado</span>
      </div>

      <form id="passForm">
        <div class="form-grid">
          <label>Fecha
            <input id="date" type="date" required>
          </label>
          <label>Grupo
            <input id="group" type="text" placeholder="Ej. 4A" maxlength="20" required>
          </label>
          <label class="wide">Nombre del alumno
            <input id="passName" type="text" placeholder="Nombre completo" required>
          </label>
          <label class="wide">Motivo
            <select id="reason" required>
              <option value="">Seleccionar motivo...</option>
              <option>Actividades culturales</option>
              <option>Enfermedad</option>
              <option>Emergencia familiar o de fuerza mayor</option>
              <option>Accidente o lesion</option>
              <option>Otro</option>
            </select>
          </label>
          <label id="otherReasonWrap" class="wide other-reason hidden">Motivo personalizado
            <input id="otherReason" type="text" placeholder="Escribe el motivo" autocomplete="off" spellcheck="false" autocorrect="off" autocapitalize="sentences">
          </label>
          <label>Hora
            <input id="time" type="time" required>
          </label>

        </div>

        <div class="form-tip">
          <span>✓</span> Al enviar, los datos se colocarán automáticamente en la plantilla del pase de salida.
        </div>

        <div class="panel-footer">
          <button type="button" class="secondary-btn prev-btn" data-prev="1">← Volver</button>
          <button type="submit" class="primary-btn">Generar vista previa →</button>
        </div>
      </form>
    </section>

    <section id="step3" class="panel step-panel">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">SECCIÓN 03</p>
          <h3>Vista previa del documento</h3>
        </div>
        <span class="badge ok">Listo para generar</span>
      </div>

      <div class="preview-wrap">
        <canvas id="passCanvas" width="1600" height="950" aria-label="Vista previa del pase de salida"></canvas>
      </div>

      <div class="preview-info">
        <div>
          <strong>Imagen final</strong>
          <p>Abre la imagen en una pestaña nueva y usa “Guardar imagen como…” con clic derecho, o descarga el PNG directamente.</p>
        </div>
        <div class="preview-actions">
          <button id="openImageBtn" class="secondary-btn">Abrir imagen</button>
          <button id="downloadBtn" class="primary-btn">Guardar PNG</button>
        </div>
      </div>

      <div class="panel-footer">
        <button class="secondary-btn prev-btn" data-prev="2">← Editar datos</button>
      </div>
    </section>
  </main>

  <script src="app.js?v=4.0.4" defer></script>
</body>
</html>
