CREATE TABLE IF NOT EXISTS configuraciones_usuario (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    fondo VARCHAR(50) NOT NULL DEFAULT 'fondo_claro1',
    modo VARCHAR(10) NOT NULL DEFAULT 'claro',
    imagenes_decorativas TINYINT(1) NOT NULL DEFAULT 1,
    color_institucional VARCHAR(10) NOT NULL DEFAULT 'azul',
    creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_configuracion_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios_sistema(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT uq_configuracion_usuario UNIQUE (usuario_id)
) ENGINE=InnoDB;
