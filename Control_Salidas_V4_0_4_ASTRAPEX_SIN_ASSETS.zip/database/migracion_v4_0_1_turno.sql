USE control_salidas;

ALTER TABLE alumnos
  ADD COLUMN turno ENUM('Matutino','Vespertino') NOT NULL DEFAULT 'Matutino' AFTER semestre;
