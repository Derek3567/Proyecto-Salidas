/* Capa única de comunicación entre la interfaz y PHP/MySQL. */
(() => {
  const config = window.APP_CONFIG || { apiBase: 'api', databaseMode: false };
  const apiBase = String(config.apiBase || 'api').replace(/\/$/, '');

  async function request(endpoint, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const response = await fetch(`${apiBase}/${endpoint}`, {
      credentials: 'same-origin',
      ...options,
      headers,
    });

    const data = await response.json().catch(() => ({
      ok: false,
      error: 'Respuesta inválida del servidor.'
    }));

    if (!response.ok || data.ok === false) {
      throw new Error(data.error || 'Error del servidor.');
    }
    return data;
  }

  window.DB = {
    enabled: config.databaseMode === true,
    status: () => request('auth.php?action=status'),
    login: payload => request('auth.php?action=login', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
    register: payload => request('auth.php?action=register', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),
    logout: () => request('auth.php?action=logout', {
      method: 'POST',
      body: '{}'
    }),
    authorizePurge: password => request('auth.php?action=authorize_purge', {
      method: 'POST',
      body: JSON.stringify({ password })
    }),
    purgeSemesters: (token, semesters) => request('auth.php?action=purge_semesters', {
      method: 'POST',
      body: JSON.stringify({ token, semesters })
    }),
    getSettings: () => request('settings.php'),
    saveSettings: payload => request('settings.php', {
      method: 'PUT',
      body: JSON.stringify(payload)
    }),
    listAlumnos: () => request('alumnos.php'),
    saveAlumno: (payload, method = 'POST', id = '') => request(
      `alumnos.php${id ? `?id=${encodeURIComponent(id)}` : ''}`,
      { method, body: JSON.stringify(payload) }
    ),
    deleteAlumno: id => request(`alumnos.php?id=${encodeURIComponent(id)}`, {
      method: 'DELETE'
    }),
    listTutores: () => request('tutores.php'),
    saveTutor: (payload, method = 'POST', id = '') => request(
      `tutores.php${id ? `?id=${encodeURIComponent(id)}` : ''}`,
      { method, body: JSON.stringify(payload) }
    ),
    deleteTutor: id => request(`tutores.php?id=${encodeURIComponent(id)}`, {
      method: 'DELETE'
    }),
  };
})();
