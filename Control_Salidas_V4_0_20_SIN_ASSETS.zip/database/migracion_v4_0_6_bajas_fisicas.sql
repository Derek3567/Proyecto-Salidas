-- V4.0.6 - Bajas físicas de alumnos y tutores
-- Ejecutar UNA SOLA VEZ sobre una base de datos existente.

USE control_salidas;

ALTER TABLE tutores_autorizados DROP FOREIGN KEY fk_tutor_alumno;
ALTER TABLE alumnos DROP COLUMN activo;
ALTER TABLE tutores_autorizados DROP COLUMN activo;
ALTER TABLE tutores_autorizados
  ADD CONSTRAINT fk_tutor_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos(id)
  ON UPDATE CASCADE ON DELETE CASCADE;
