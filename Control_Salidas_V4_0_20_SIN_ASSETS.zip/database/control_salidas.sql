CREATE DATABASE IF NOT EXISTS control_salidas
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE control_salidas;

CREATE TABLE IF NOT EXISTS usuarios_sistema (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alumnos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(120) NOT NULL,
  apellidos VARCHAR(160) NOT NULL,
  matricula VARCHAR(14) NOT NULL UNIQUE,
  semestre TINYINT UNSIGNED NOT NULL,
  turno ENUM('Matutino','Vespertino') NOT NULL DEFAULT 'Matutino',
  grupo VARCHAR(20) NOT NULL,
  especialidad VARCHAR(100) NOT NULL,
  ine_1_path VARCHAR(255) NULL,
  ine_2_path VARCHAR(255) NULL,
  ine_3_path VARCHAR(255) NULL,
  ine_4_path VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tutores_autorizados (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  alumno_id INT UNSIGNED NULL,
  nombres VARCHAR(120) NOT NULL,
  apellidos VARCHAR(160) NOT NULL,
  parentesco VARCHAR(60) NOT NULL,
  telefono VARCHAR(10) NOT NULL,
  codigo VARCHAR(40) NOT NULL UNIQUE,
  CONSTRAINT fk_tutor_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos(id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS configuraciones_usuario (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NOT NULL,
  fondo VARCHAR(50) NOT NULL DEFAULT 'fondo_claro1',
  modo VARCHAR(10) NOT NULL DEFAULT 'claro',
  imagenes_decorativas TINYINT(1) NOT NULL DEFAULT 1,
  color_institucional VARCHAR(10) NOT NULL DEFAULT 'azul',
  CONSTRAINT fk_configuracion_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios_sistema(id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT uq_configuracion_usuario UNIQUE (usuario_id)
) ENGINE=InnoDB;
