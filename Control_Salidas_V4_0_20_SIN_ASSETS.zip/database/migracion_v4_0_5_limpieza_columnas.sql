-- V4.0.5 - Limpieza de columnas heredadas no utilizadas
-- Ejecutar UNA SOLA VEZ sobre una base de datos existente.

USE control_salidas;

ALTER TABLE configuraciones_usuario
  DROP COLUMN creado_en,
  DROP COLUMN actualizado_en;

ALTER TABLE tutores_autorizados
  DROP COLUMN alumno_nombre;

ALTER TABLE alumnos
  DROP COLUMN tutor_nombres,
  DROP COLUMN tutor_apellidos;
