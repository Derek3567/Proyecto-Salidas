# Base de datos — V3.12.3

La tabla adicional necesaria es `configuraciones_usuario`. Si ya fue creada como se indicó para V3.12, no hay que crearla nuevamente.

La definición actual se encuentra en `database/migracion_v3_12_configuraciones.sql`. Los valores predeterminados son fondo `fondo_claro1`, modo `claro`, imágenes decorativas activadas y color institucional azul.

No importar de nuevo las tablas existentes. No ejecutar `setup.php` si la cuenta inicial ya existe.

Conservar `private_uploads/ines/` al actualizar una instalación existente.

V3.13 no requiere cambios de base de datos. Usa las tablas existentes, incluida configuraciones_usuario creada en V3.12.

## V4.0.0 — Cuentas del personal
No se agrega ninguna tabla nueva. La creación de cuentas usa `usuarios_sistema` y crea automáticamente su configuración en `configuraciones_usuario`.

El límite de 12 cuentas se valida en `api/auth.php` y contempla todas las cuentas existentes en `usuarios_sistema`.


## Paquete de prueba local
Este paquete está configurado para la base de datos `control_salidas`. El código de producción usa `control_salidas`; fuera de esta copia no se cambia nada.


V4.0.1: run `database/migracion_v4_0_1_turno.sql` on an existing installation to add the student shift. New databases created from `database/schema.sql` or `database/control_salidas.sql` already include the column.


### V4.0.5 — Limpieza de columnas
Para una base existente, ejecutar una sola vez `database/migracion_v4_0_5_limpieza_columnas.sql`. Esta migración elimina únicamente columnas que el sistema ya no utiliza: `configuraciones_usuario.creado_en`, `configuraciones_usuario.actualizado_en`, `tutores_autorizados.alumno_nombre`, `alumnos.tutor_nombres` y `alumnos.tutor_apellidos`.


## V4.0.6 - Bajas físicas

`alumnos` y `tutores_autorizados` ya no usan `activo`. Dar de baja elimina físicamente el registro. La relación tutor-alumno usa `ON DELETE CASCADE`. La aplicación elimina los archivos INE asociados al dar de baja un alumno o tutor. `usuarios_sistema.activo` se conserva porque corresponde a las cuentas de acceso. Ejecuta `database/migracion_v4_0_6_bajas_fisicas.sql` una sola vez.
