<?php
/*
 * Configuración de producción para InfinityFree.
 * La base de datos ya debe existir en el panel de InfinityFree.
 */
return [
    'host' => 'sql309.infinityfree.com',
    'port' => 3306,
    'database' => 'if0_43026442_control_salidas',
    'username' => 'if0_43026442',
    'password' => 'mFxykjLiRKm',
    'charset' => 'utf8mb4',
];
