<?php
require __DIR__ . '/_bootstrap.php';
$method=$_SERVER['REQUEST_METHOD'];
$action=$_GET['action'] ?? 'login';


function ensureActiveSessionTables(): void {
    global $pdo;
    $pdo->exec("CREATE TABLE IF NOT EXISTS sesiones_activas (
        session_id VARCHAR(128) PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        iniciado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_sesiones_usuario (usuario_id)
    ) ENGINE=InnoDB");
    $pdo->exec("CREATE TABLE IF NOT EXISTS control_sesiones_lock (
        id TINYINT UNSIGNED PRIMARY KEY,
        valor TINYINT UNSIGNED NOT NULL DEFAULT 0
    ) ENGINE=InnoDB");
    $pdo->exec("INSERT IGNORE INTO control_sesiones_lock (id, valor) VALUES (1, 0)");
}

function registerCurrentSession(): bool {
    global $pdo;
    ensureActiveSessionTables();
    $sessionId=session_id();
    $pdo->beginTransaction();
    try {
        $lock=$pdo->query('SELECT id FROM control_sesiones_lock WHERE id=1 FOR UPDATE')->fetch();
        if(!$lock) throw new RuntimeException('No se pudo bloquear el control de sesiones.');
        $stmt=$pdo->query('SELECT COUNT(*) FROM sesiones_activas');
        $active=(int)$stmt->fetchColumn();
        $existing=$pdo->prepare('SELECT usuario_id FROM sesiones_activas WHERE session_id=? LIMIT 1');
        $existing->execute([$sessionId]);
        $row=$existing->fetch();
        if(!$row && $active>=4){
            $pdo->rollBack();
            return false;
        }
        if(!$row){
            $insert=$pdo->prepare('INSERT INTO sesiones_activas(session_id,usuario_id) VALUES(?,?)');
            $insert->execute([$sessionId,(int)$_SESSION['user_id']]);
        }
        $pdo->commit();
        return true;
    } catch(Throwable $e) {
        if($pdo->inTransaction())$pdo->rollBack();
        throw $e;
    }
}

function removeCurrentSession(): void {
    global $pdo;
    try {
        ensureActiveSessionTables();
        $stmt=$pdo->prepare('DELETE FROM sesiones_activas WHERE session_id=?');
        $stmt->execute([session_id()]);
    } catch(Throwable $e) {
        // El cierre de sesión no se bloquea por un fallo del registro auxiliar.
    }
}

if($action==='status' && $method==='GET'){
    if(empty($_SESSION['user_id'])) respond(['ok'=>true,'authenticated'=>false]);
    try {
        if(!registerCurrentSession()){
            $_SESSION=[];
            if(ini_get('session.use_cookies')){
                $p=session_get_cookie_params();
                setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
            }
            session_destroy();
            respond(['ok'=>true,'authenticated'=>false,'session_limit'=>true,'error'=>'Se alcanzó el máximo de 4 sesiones activas. Cierra una sesión antes de continuar.']);
        }
    } catch(Throwable $e) {
        respond(['ok'=>false,'error'=>'No se pudo comprobar el límite de sesiones activas.'],500);
    }
    respond(['ok'=>true,'authenticated'=>true,'data'=>['id'=>(int)$_SESSION['user_id'],'nombre'=>$_SESSION['user_name'],'correo'=>$_SESSION['user_email']]]);
}

if($action==='logout' && ($method==='POST' || $method==='GET')){
    removeCurrentSession();
    $_SESSION=[];
    if(ini_get('session.use_cookies')){
        $p=session_get_cookie_params();
        setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
    }
    session_destroy();
    respond(['ok'=>true]);
}

if($method!=='POST') respond(['ok'=>false,'error'=>'Método no soportado.'],405);
$d=jsonInput();

if($action==='authorize_mass_actions' && $method==='POST'){
    requireAuth();
    $password=(string)($d['password']??'');
    if($password==='')respond(['ok'=>false,'error'=>'Escribe la contraseña de tu cuenta.'],422);
    $stmt=$pdo->prepare('SELECT password_hash FROM usuarios_sistema WHERE id=? AND activo=1 LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id']]);$user=$stmt->fetch();
    if(!$user || !password_verify($password,$user['password_hash']))respond(['ok'=>false,'error'=>'La contraseña de la cuenta no es correcta.'],401);
    $_SESSION['purge_token']=bin2hex(random_bytes(32));$_SESSION['purge_expires']=time()+300;
    $_SESSION['mass_edit_token']=bin2hex(random_bytes(32));$_SESSION['mass_edit_expires']=time()+300;
    respond(['ok'=>true,'data'=>['purge_token'=>$_SESSION['purge_token'],'mass_edit_token'=>$_SESSION['mass_edit_token'],'expires_in'=>300]]);
}

if($action==='authorize_purge' && $method==='POST'){
    requireAuth();
    $d=jsonInput();
    $password=(string)($d['password']??'');
    if($password==='')respond(['ok'=>false,'error'=>'Escribe la contraseña de tu cuenta.'],422);
    $stmt=$pdo->prepare('SELECT password_hash FROM usuarios_sistema WHERE id=? AND activo=1 LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user=$stmt->fetch();
    if(!$user || !password_verify($password,$user['password_hash']))respond(['ok'=>false,'error'=>'La contraseña de la cuenta no es correcta.'],401);
    $_SESSION['purge_token']=bin2hex(random_bytes(32));
    $_SESSION['purge_expires']=time()+300;
    respond(['ok'=>true,'data'=>['token'=>$_SESSION['purge_token'],'expires_in'=>300]]);
}


if($action==='authorize_mass_edit' && $method==='POST'){
    requireAuth();
    $d=jsonInput();
    $password=(string)($d['password']??'');
    if($password==='')respond(['ok'=>false,'error'=>'Escribe la contraseña de tu cuenta.'],422);
    $stmt=$pdo->prepare('SELECT password_hash FROM usuarios_sistema WHERE id=? AND activo=1 LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user=$stmt->fetch();
    if(!$user || !password_verify($password,$user['password_hash']))respond(['ok'=>false,'error'=>'La contraseña de la cuenta no es correcta.'],401);
    $_SESSION['mass_edit_token']=bin2hex(random_bytes(32));
    $_SESSION['mass_edit_expires']=time()+300;
    respond(['ok'=>true,'data'=>['token'=>$_SESSION['mass_edit_token'],'expires_in'=>300]]);
}

if($action==='mass_edit_students' && $method==='POST'){
    requireAuth();
    $d=jsonInput();
    $token=(string)($d['token']??'');
    $expires=(int)($_SESSION['mass_edit_expires']??0);
    $sessionToken=(string)($_SESSION['mass_edit_token']??'');
    if(!$token || !$sessionToken || $expires<time() || !hash_equals($sessionToken,$token))respond(['ok'=>false,'error'=>'La autorización de modificación expiró. Vuelve a verificar tu contraseña.'],401);

    $sourceSemester=(int)($d['source_semester']??0);
    $sourceGroup=strtoupper(trim((string)($d['source_group']??'')));
    $newSemester=$d['new_semester']??null;
    $newTurno=$d['new_turno']??null;
    $newSpecialty=$d['new_specialty']??null;
    if($sourceSemester<1||$sourceSemester>6||($sourceGroup!=='' && !preg_match('/^[A-M]$/',$sourceGroup)))respond(['ok'=>false,'error'=>'El grupo de origen no es válido.'],422);
    $newSemester=($newSemester===null||$newSemester==='')?null:(int)$newSemester;
    if($newSemester!==null && ($newSemester<1||$newSemester>6))respond(['ok'=>false,'error'=>'El nuevo semestre no es válido.'],422);
    $newTurno=($newTurno===null||$newTurno==='')?null:trim((string)$newTurno);
    if($newTurno!==null && !in_array($newTurno,['Matutino','Vespertino'],true))respond(['ok'=>false,'error'=>'El nuevo turno no es válido.'],422);
    $newSpecialty=($newSpecialty===null||$newSpecialty==='')?null:trim((string)$newSpecialty);
    if($newSemester===null && $newTurno===null && $newSpecialty===null)respond(['ok'=>false,'error'=>'Selecciona al menos un dato para modificar.'],422);
    if($sourceGroup===''){$check=$pdo->prepare('SELECT COUNT(*) FROM alumnos WHERE semestre=?');$check->execute([$sourceSemester]);}
    else{$check=$pdo->prepare('SELECT COUNT(*) FROM alumnos WHERE semestre=? AND grupo=?');$check->execute([$sourceSemester,$sourceGroup]);}
    $matched=(int)$check->fetchColumn();
    if($matched<1)respond(['ok'=>false,'error'=>'No hay alumnos registrados en el semestre y grupo seleccionados.'],404);
    $sets=[];$params=[];
    if($newSemester!==null){$sets[]='semestre=?';$params[]=$newSemester;}
    if($newTurno!==null){$sets[]='turno=?';$params[]=$newTurno;}
    if($newSpecialty!==null){$sets[]='especialidad=?';$params[]=$newSpecialty;}
    $params[]=$sourceSemester;
    $where='semestre=?';
    if($sourceGroup!==''){$params[]=$sourceGroup;$where.=' AND grupo=?';}
    try{
        $pdo->beginTransaction();
        $stmt=$pdo->prepare('UPDATE alumnos SET '.implode(',',$sets).' WHERE '.$where);
        $stmt->execute($params);
        $updated=$stmt->rowCount();
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();respond(['ok'=>false,'error'=>'No se pudieron modificar los registros seleccionados.'],500);}
    unset($_SESSION['mass_edit_token'],$_SESSION['mass_edit_expires']);
    respond(['ok'=>true,'data'=>['students_updated'=>$updated,'source_semester'=>$sourceSemester,'source_group'=>$sourceGroup,'new_semester'=>$newSemester,'new_turno'=>$newTurno,'new_specialty'=>$newSpecialty]]);
}

if($action==='purge_semesters' && $method==='POST'){
    requireAuth();
    $d=jsonInput();
    $token=(string)($d['token']??'');
    $expires=(int)($_SESSION['purge_expires']??0);
    $sessionToken=(string)($_SESSION['purge_token']??'');
    if(!$token || !$sessionToken || $expires<time() || !hash_equals($sessionToken,$token))respond(['ok'=>false,'error'=>'La autorización de borrado expiró. Vuelve a verificar tu contraseña.'],401);

    $semesters=$d['semesters']??[];
    $groups=$d['groups']??[];
    $specialties=$d['specialties']??[];
    foreach(['semesters'=>$semesters,'groups'=>$groups,'specialties'=>$specialties] as $key=>$value){
        if(!is_array($value))respond(['ok'=>false,'error'=>"El filtro de $key no es válido."],422);
    }
    $semesters=array_values(array_unique(array_map('intval',$semesters)));
    $semesters=array_values(array_filter($semesters,fn($n)=>$n>=1&&$n<=6));
    $groups=array_values(array_unique(array_filter(array_map(fn($v)=>strtoupper(trim((string)$v),),$groups),fn($v)=>preg_match('/^[A-M]$/',$v))));
    $specialties=array_values(array_unique(array_filter(array_map(fn($v)=>trim((string)$v),$specialties),fn($v)=>$v!=='')));
    if(!$semesters && !$groups && !$specialties)respond(['ok'=>false,'error'=>'Selecciona al menos un semestre, grupo o especialidad.'],422);

    $where=[];$params=[];
    if($semesters){$where[]='semestre IN ('.implode(',',array_fill(0,count($semesters),'?')).')';$params=array_merge($params,$semesters);}
    if($groups){$where[]='grupo IN ('.implode(',',array_fill(0,count($groups),'?')).')';$params=array_merge($params,$groups);}
    if($specialties){$where[]='especialidad IN ('.implode(',',array_fill(0,count($specialties),'?')).')';$params=array_merge($params,$specialties);}
    $whereSql=implode(' AND ',$where);

    $studentsStmt=$pdo->prepare("SELECT id,ine_1_path,ine_2_path,ine_3_path,ine_4_path FROM alumnos WHERE $whereSql");
    $studentsStmt->execute($params);
    $students=$studentsStmt->fetchAll();
    $studentIds=array_map(fn($r)=>(int)$r['id'],$students);
    $paths=[];
    foreach($students as $row){foreach(['ine_1_path','ine_2_path','ine_3_path','ine_4_path'] as $key){if(!empty($row[$key]))$paths[]=basename($row[$key]);}}
    $paths=array_values(array_unique($paths));
    $deletedStudents=0;$deletedTutors=0;
    try{
        $pdo->beginTransaction();
        if($studentIds){
            $idPlaceholders=implode(',',array_fill(0,count($studentIds),'?'));
            $countTutor=$pdo->prepare("SELECT COUNT(*) FROM tutores_autorizados WHERE alumno_id IN ($idPlaceholders)");
            $countTutor->execute($studentIds);$deletedTutors=(int)$countTutor->fetchColumn();
            $delTutors=$pdo->prepare("DELETE FROM tutores_autorizados WHERE alumno_id IN ($idPlaceholders)");
            $delTutors->execute($studentIds);
            $delStudents=$pdo->prepare("DELETE FROM alumnos WHERE id IN ($idPlaceholders)");
            $delStudents->execute($studentIds);$deletedStudents=$delStudents->rowCount();
        }
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();respond(['ok'=>false,'error'=>'No se pudieron borrar los registros seleccionados.'],500);}
    foreach($paths as $file){$full=dirname(__DIR__).'/private_uploads/ines/'.basename($file);if(is_file($full))@unlink($full);}
    unset($_SESSION['purge_token'],$_SESSION['purge_expires']);
    respond(['ok'=>true,'data'=>['semesters'=>$semesters,'groups'=>$groups,'specialties'=>$specialties,'students_deleted'=>$deletedStudents,'tutors_deleted'=>$deletedTutors,'ines_deleted'=>count($paths)]]);
}

if($action==='register'){
    foreach(['nombre','correo','password'] as $key){if(empty($d[$key]))respond(['ok'=>false,'error'=>"Falta el campo: $key"],422);}
    $nombre=trim((string)$d['nombre']);
    $correo=strtolower(trim((string)$d['correo']));
    $password=(string)$d['password'];
    if($nombre==='' || mb_strlen($nombre)>120 || !preg_match("/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+(?:[ '\\-][A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+)*$/u",$nombre))respond(['ok'=>false,'error'=>'El nombre solo puede contener letras, espacios, guiones o apóstrofes y tener como máximo 120 caracteres.'],422);
    if(!filter_var($correo,FILTER_VALIDATE_EMAIL))respond(['ok'=>false,'error'=>'Correo inválido.'],422);
    if(!preg_match('/^(?=.{10,}$)(?!.*\s)(?=.*[A-Za-z])(?=.*[A-Z])(?=.*\d).*$/',$password))respond(['ok'=>false,'error'=>'La contraseña debe tener 10 caracteres, sin espacios, con número, letra y mayúscula.'],422);

    try{
        $pdo->beginTransaction();
        $count=(int)$pdo->query('SELECT COUNT(*) FROM usuarios_sistema FOR UPDATE')->fetchColumn();
        if($count>=12){$pdo->rollBack();respond(['ok'=>false,'error'=>'Se alcanzó el máximo de 12 cuentas permitidas.'],409);}
        $stmt=$pdo->prepare('SELECT id FROM usuarios_sistema WHERE correo=? LIMIT 1');
        $stmt->execute([$correo]);
        if($stmt->fetch()){$pdo->rollBack();respond(['ok'=>false,'error'=>'Ya existe una cuenta con ese correo electrónico.'],409);}
        $stmt=$pdo->prepare('INSERT INTO usuarios_sistema(nombre,correo,password_hash) VALUES(?,?,?)');
        $stmt->execute([$nombre,$correo,password_hash($password,PASSWORD_DEFAULT)]);
        $newId=(int)$pdo->lastInsertId();
        $stmt=$pdo->prepare("INSERT INTO configuraciones_usuario (usuario_id,fondo,modo,imagenes_decorativas,color_institucional) VALUES (?, 'fondo_claro1','claro',1,'azul')");
        $stmt->execute([$newId]);
        $pdo->commit();
        respond(['ok'=>true,'id'=>$newId,'data'=>['nombre'=>$nombre,'correo'=>$correo]]);
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        if($e instanceof PDOException && (int)$e->errorInfo[1]===1062)respond(['ok'=>false,'error'=>'Ya existe una cuenta con ese correo electrónico.'],409);
        respond(['ok'=>false,'error'=>'No se pudo crear la cuenta.'],500);
    }
}

if($action==='login'){
    foreach(['nombre','correo','password'] as $key){if(empty($d[$key]))respond(['ok'=>false,'error'=>"Falta el campo: $key"],422);}
    $email=strtolower(trim((string)$d['correo']));
    $stmt=$pdo->prepare('SELECT id,nombre,correo,password_hash FROM usuarios_sistema WHERE correo=? AND activo=1 LIMIT 1');
    $stmt->execute([$email]);
    $user=$stmt->fetch();
    if(!$user || !password_verify((string)$d['password'],$user['password_hash']))respond(['ok'=>false,'error'=>'Correo o contraseña incorrectos.'],401);
    if(strcasecmp(trim((string)$d['nombre']),trim((string)$user['nombre']))!==0)respond(['ok'=>false,'error'=>'El nombre no coincide con la cuenta.'],401);
    session_regenerate_id(true);
    $_SESSION['user_id']=(int)$user['id'];
    $_SESSION['user_name']=$user['nombre'];
    $_SESSION['user_email']=$user['correo'];
    try {
        if(!registerCurrentSession()){
            $_SESSION=[];
            if(ini_get('session.use_cookies')){
                $p=session_get_cookie_params();
                setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
            }
            session_destroy();
            respond(['ok'=>false,'error'=>'Ya hay 4 personas dentro de la página. Cierra una sesión antes de iniciar otra.'],409);
        }
    } catch(Throwable $e) {
        $_SESSION=[];
        session_destroy();
        respond(['ok'=>false,'error'=>'No se pudo comprobar el límite de sesiones activas.'],500);
    }
    respond(['ok'=>true,'data'=>['id'=>(int)$user['id'],'nombre'=>$user['nombre'],'correo'=>$user['correo']]]);
}
respond(['ok'=>false,'error'=>'Acción no soportada.'],400);
