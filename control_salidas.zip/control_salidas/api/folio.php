<?php
require_once __DIR__ . '/_bootstrap.php';
requireAuth();
if (($_GET['action'] ?? '') !== 'next' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(['ok'=>false,'error'=>'Solicitud no válida.'], 405);
}
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS contador_folios (id TINYINT UNSIGNED NOT NULL PRIMARY KEY, siguiente BIGINT UNSIGNED NOT NULL) ENGINE=InnoDB");
    $pdo->exec("INSERT IGNORE INTO contador_folios (id, siguiente) VALUES (1, 1)");
    $pdo->beginTransaction();
    $stmt=$pdo->query("SELECT siguiente FROM contador_folios WHERE id=1 FOR UPDATE");
    $folio=(int)$stmt->fetchColumn();
    if ($folio < 1 || $folio > 9999) $folio=1;
    $siguiente = ($folio >= 9999) ? 1 : $folio + 1;
    $update=$pdo->prepare("UPDATE contador_folios SET siguiente=? WHERE id=1");
    $update->execute([$siguiente]);
    $pdo->commit();
    respond(['ok'=>true,'folio'=>str_pad((string)$folio, 4, '0', STR_PAD_LEFT)]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Folio consecutivo: '.$e->getMessage());
    respond(['ok'=>false,'error'=>'No fue posible reservar un folio.'],500);
}
